import java.sql.*;
import java.awt.Font;
import javax.swing.*;
import java.awt.Color;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AdminHome extends JFrame {
    private static final long serialVersionUID = 1L;
    public static String email;
    public static String mob;
    public static String pass;

    private JLabel setName, setMob, setEmail;

    AdminHome(String email, String mob, String pass) {
        AdminHome.email = email;
        AdminHome.mob = mob;
        AdminHome.pass = pass;

        setTitle("Admin Home");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 600);

        JTabbedPane tabPanel = new JTabbedPane();
        tabPanel.setBackground(Color.WHITE);

        JPanel page1 = createProfilePanel();
        tabPanel.addTab("Profile", page1);

        JPanel page2 = createBusAddPanel();
        tabPanel.addTab("Add New Buses", page2);

        getContentPane().add(tabPanel);
        setVisible(true);

        loadAdminData();
    }

    private JPanel createProfilePanel() {
        JPanel panel = new JPanel();
        panel.setBackground(new Color(216, 191, 216));
        panel.setLayout(null);

        JLabel lblName = new JLabel("Name:");
        lblName.setFont(new Font("Times New Roman", Font.BOLD, 13));
        lblName.setBounds(35, 82, 131, 21);
        panel.add(lblName);

        JLabel lblMobileNumber = new JLabel("Mobile Number:");
        lblMobileNumber.setFont(new Font("Times New Roman", Font.BOLD, 13));
        lblMobileNumber.setBounds(35, 126, 131, 21);
        panel.add(lblMobileNumber);

        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setFont(new Font("Times New Roman", Font.BOLD, 13));
        lblEmail.setBounds(35, 180, 131, 21);
        panel.add(lblEmail);

        setName = new JLabel();
        setName.setBounds(205, 82, 131, 21);
        panel.add(setName);

        setMob = new JLabel();
        setMob.setBounds(205, 126, 131, 21);
        panel.add(setMob);

        setEmail = new JLabel();
        setEmail.setBounds(205, 180, 131, 21);
        panel.add(setEmail);

        JButton btnLogout = new JButton("Logout");
        btnLogout.addActionListener(e -> {
            AdminLogin ul = new AdminLogin();
            setVisible(false);
            ul.setVisible(true);
        });
        btnLogout.setBounds(0, 10, 85, 21);
        panel.add(btnLogout);

        return panel;
    }

    private JPanel createBusAddPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(new Color(216, 191, 216));
        panel.setLayout(null);

        JLabel lblBusId = new JLabel("Bus ID:");
        lblBusId.setFont(new Font("Times New Roman", Font.BOLD, 13));
        lblBusId.setBounds(30, 50, 100, 25);
        panel.add(lblBusId);

        JTextField busIdField = new JTextField();
        busIdField.setBounds(140, 50, 150, 25);
        panel.add(busIdField);

        JLabel lblSource = new JLabel("Source:");
        lblSource.setFont(new Font("Times New Roman", Font.BOLD, 13));
        lblSource.setBounds(30, 100, 100, 25);
        panel.add(lblSource);

        JTextField sourceField = new JTextField();
        sourceField.setBounds(140, 100, 150, 25);
        panel.add(sourceField);

        JLabel lblDestination = new JLabel("Destination:");
        lblDestination.setFont(new Font("Times New Roman", Font.BOLD, 13));
        lblDestination.setBounds(30, 150, 100, 25);
        panel.add(lblDestination);

        JTextField destinationField = new JTextField();
        destinationField.setBounds(140, 150, 150, 25);
        panel.add(destinationField);

        JLabel lblPrice = new JLabel("Price:");
        lblPrice.setFont(new Font("Times New Roman", Font.BOLD, 13));
        lblPrice.setBounds(30, 200, 100, 25);
        panel.add(lblPrice);

        JTextField priceField = new JTextField();
        priceField.setBounds(140, 200, 150, 25);
        panel.add(priceField);

        JLabel lblSeats = new JLabel("Seats Available:");
        lblSeats.setFont(new Font("Times New Roman", Font.BOLD, 13));
        lblSeats.setBounds(30, 250, 150, 25);
        panel.add(lblSeats);

        JTextField seatsField = new JTextField();
        seatsField.setBounds(180, 250, 150, 25);
        panel.add(seatsField);

        JLabel lblCapacity = new JLabel("Bus Capacity:");
        lblCapacity.setFont(new Font("Times New Roman", Font.BOLD, 13));
        lblCapacity.setBounds(30, 300, 150, 25);
        panel.add(lblCapacity);

        JTextField capacityField = new JTextField();
        capacityField.setBounds(180, 300, 150, 25);
        panel.add(capacityField);

        JLabel lblTimeAvailable = new JLabel("Time Available:");
        lblTimeAvailable.setFont(new Font("Times New Roman", Font.BOLD, 13));
        lblTimeAvailable.setBounds(30, 350, 150, 25);
        panel.add(lblTimeAvailable);

        JTextField timeAvailableField = new JTextField();
        timeAvailableField.setBounds(180, 350, 150, 25);
        panel.add(timeAvailableField);

        JLabel lblDateAvailable = new JLabel("Date Available (yyyy-MM-dd):");
        lblDateAvailable.setFont(new Font("Times New Roman", Font.BOLD, 13));
        lblDateAvailable.setBounds(30, 400, 200, 25);
        panel.add(lblDateAvailable);

        JTextField dateAvailableField = new JTextField();
        dateAvailableField.setBounds(230, 400, 150, 25);
        panel.add(dateAvailableField);

        JButton btnAddBus = new JButton("Add Bus");
        btnAddBus.setBounds(100, 450, 150, 25);
        btnAddBus.addActionListener(e -> {
            String busId = busIdField.getText().trim();
            String source = sourceField.getText().trim();
            String destination = destinationField.getText().trim();
            String price = priceField.getText().trim();
            String seats = seatsField.getText().trim();
            String capacity = capacityField.getText().trim();
            String timeAvailable = timeAvailableField.getText().trim();
            String dateAvailable = dateAvailableField.getText().trim();

            if (busId.isEmpty() || source.isEmpty() || destination.isEmpty() || price.isEmpty() || seats.isEmpty() || capacity.isEmpty() || timeAvailable.isEmpty() || dateAvailable.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                double priceValue = Double.parseDouble(price);
                int seatsValue = Integer.parseInt(seats);
                int capacityValue = Integer.parseInt(capacity);

                if (addBusDetails(busId, source, destination, priceValue, seatsValue, capacityValue, timeAvailable, dateAvailable)) {
                    JOptionPane.showMessageDialog(panel, "Bus added successfully!");
                } else {
                    JOptionPane.showMessageDialog(panel, "Failed to add bus. Check the details.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(panel, "Invalid price, seats or capacity. Please enter valid numbers.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        panel.add(btnAddBus);

        return panel;
    }

    private boolean addBusDetails(String busId, String source, String destination, double price, int seats, int capacity, String timeAvailable, String dateAvailable) {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bus_ticket", "root", "Jac@231005");
             PreparedStatement ps = con.prepareStatement("INSERT INTO bus (Bus_Id, Source, Destination, Price, Seats_Available, Bus_Capacity, Time_Available, Date_Available) VALUES (?,?,?,?,?,?,?,?)")) {
            ps.setString(1, busId);
            ps.setString(2, source);
            ps.setString(3, destination);
            ps.setDouble(4, price);
            ps.setInt(5, seats);
            ps.setInt(6, capacity);
            ps.setString(7, timeAvailable);
            ps.setString(8, dateAvailable);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }

    private void loadAdminData() {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bus_ticket", "root", "Jac@231005");
             PreparedStatement ps = con.prepareStatement("SELECT * FROM admin WHERE email =? OR mobile =?")) {
            ps.setString(1, email);
            ps.setString(2, mob);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    setName.setText(rs.getString("name"));
                    setMob.setText(rs.getString("mobile"));
                    setEmail.setText(rs.getString("email"));
                } else {
                    setName.setText("Not found");
                    setMob.setText("Not found");
                    setEmail.setText("Not found");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading admin data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        AdminHome adminh = new AdminHome("admin@example.com", "9876543210", "admin1234");
        adminh.setVisible(true);
    }
}