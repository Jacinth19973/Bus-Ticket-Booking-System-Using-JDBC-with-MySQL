import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class UserLogin extends JFrame {
    private static final long serialVersionUID = 1L;
    private JTextField txtMob;

    public UserLogin() {
        // Setting JFrame properties
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 613, 532);
        setTitle("User Login Page");

        getContentPane().setLayout(null);

        JLabel head = new JLabel("User Login", JLabel.CENTER);
        head.setFont(new Font("Times New Roman", Font.BOLD, 26));
        head.setForeground(Color.RED);
        head.setBounds(216, 10, 150, 30);
        getContentPane().add(head);
        getContentPane().setBackground(new Color(255, 255, 255));

        JPanel panel = new JPanel();
        panel.setBackground(new Color(32, 178, 170));
        panel.setBounds(10, 59, 579, 426);
        getContentPane().add(panel);
        panel.setLayout(null);

        JLabel lblMob = new JLabel("Mobile Number");
        lblMob.setBounds(83, 168, 135, 30);
        panel.add(lblMob);
        lblMob.setHorizontalAlignment(SwingConstants.CENTER);
        lblMob.setFont(new Font("Times New Roman", Font.PLAIN, 18));

        txtMob = new JTextField(20);
        txtMob.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        txtMob.setBounds(263, 168, 200, 30);
        panel.add(txtMob);

        JButton btnLogin = new JButton("Login");
        btnLogin.setBounds(220, 236, 100, 30);
        panel.add(btnLogin);
        btnLogin.setFont(new Font("Times New Roman", Font.PLAIN, 16));

        JLabel l3 = new JLabel("Not have an account?");
        l3.setBounds(381, 293, 155, 30);
        panel.add(l3);
        l3.setFont(new Font("Times New Roman", Font.PLAIN, 17));

        JButton btnSignUp = new JButton("Sign Up");
        btnSignUp.setBounds(401, 333, 100, 30);
        panel.add(btnSignUp);
        btnSignUp.setFont(new Font("Times New Roman", Font.PLAIN, 16));

        // Action Listener for Sign Up button
        btnSignUp.addActionListener(e -> {
            UserRegister userRegister = new UserRegister();
            userRegister.setVisible(true);
            setVisible(false);
        });

        // Action Listener for Login button
        btnLogin.addActionListener(e -> handleLogin());
    }

    private void handleLogin() {
        String mobile = txtMob.getText().trim();

        // Validate inputs
        if (mobile.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter your Mobile Number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Ensure the driver is loaded
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the database connection
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bus_ticket", "root", "Jac@231005");
            String sql = "SELECT * FROM user WHERE mobile =?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, mobile);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                // Login successful
                JOptionPane.showMessageDialog(this, "Login successful!", "Success", JOptionPane.INFORMATION_MESSAGE);

                // Navigate to UserHome1
                UserHome1 userHome = new UserHome1(mobile, mobile);
                userHome.setVisible(true);
                setVisible(false);
            } else {
                // Login failed
                JOptionPane.showMessageDialog(this, "Invalid login credentials.", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }

            // Close the connection
            con.close();
        } catch (ClassNotFoundException cnfe) {
            JOptionPane.showMessageDialog(this, "MySQL JDBC Driver not found.", "Driver Error", JOptionPane.ERROR_MESSAGE);
            cnfe.printStackTrace();
        } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(this, "Database error: " + sqle.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            sqle.printStackTrace();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        // Run the UserLogin application
        SwingUtilities.invokeLater(() -> {
            UserLogin userLogin = new UserLogin();
            userLogin.setVisible(true);
        });
    }
}