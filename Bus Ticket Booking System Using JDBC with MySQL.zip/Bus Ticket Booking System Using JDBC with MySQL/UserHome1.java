import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class UserHome1 extends JFrame {
    private static final long serialVersionUID = 1L;

    public UserHome1(String email, String mobile) {
        // Set JFrame properties
        setTitle("User Home");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        // Create a main panel with GridBagLayout for better alignment
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(173, 216, 230));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Welcome label
        JLabel lblWelcome = new JLabel("Welcome to User Home!");
        lblWelcome.setFont(new Font("Times New Roman", Font.BOLD, 24));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(lblWelcome, gbc);

        // Fetch user details
        String userName = fetchUserName(mobile);

        // Display user information
        //JLabel lblName = new JLabel("Name: " + userName);
        //lblName.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        //gbc.gridy = 1;
        //panel.add(lblName, gbc);

        //JLabel lblEmail = new JLabel("Email: " + email);
        //lblEmail.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        //gbc.gridy = 1;
        //panel.add(lblEmail, gbc);

        //JLabel lblMobile = new JLabel("Mobile: " + mobile);
        //lblMobile.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        //gbc.gridy = 3;
        //panel.add(lblMobile, gbc);

        // Button to navigate to bookings
        JButton btnBookings = new JButton("Book Tickets");
        btnBookings.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        gbc.gridy = 4;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        panel.add(btnBookings, gbc);
        btnBookings.addActionListener(e -> {
            JFrame bookingFrame = new JFrame("Book Tickets");
            bookingFrame.setSize(600, 400);
            bookingFrame.setLocationRelativeTo(null);

            JPanel bookingPanel = createBookingsPanel(mobile);
            bookingFrame.add(bookingPanel);

            bookingFrame.setVisible(true);
            setVisible(false); // Hide the current frame
        });

        // Logout button
        JButton btnLogout = new JButton("Logout");
        btnLogout.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        gbc.gridy = 5;
        panel.add(btnLogout, gbc);
        btnLogout.addActionListener(e -> {
            UserLogin userLogin = new UserLogin();
            userLogin.setVisible(true);
            setVisible(false);
        });

        // Add the main panel to the frame
        getContentPane().add(panel);
    }

    private String fetchUserName(String mobile) {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bus_ticket", "root", "Jac@231005");
             PreparedStatement ps = con.prepareStatement("SELECT Name FROM user WHERE Mobile =?")) {
            ps.setString(1, mobile);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("Name");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching user name: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return "Unknown";
    }

    private JPanel createBookingsPanel(String mobile) {
        JPanel panel = new JPanel();
        panel.setBackground(new Color(240, 230, 140));
        panel.setLayout(null);

        JLabel lblSource = new JLabel("Source:");
        lblSource.setBounds(30, 20, 100, 25);
        panel.add(lblSource);

        JTextField sourceField = new JTextField();
        sourceField.setBounds(140, 20, 150, 25);
        panel.add(sourceField);

        JLabel lblDestination = new JLabel("Destination:");
        lblDestination.setBounds(30, 60, 100, 25);
        panel.add(lblDestination);

        JTextField destinationField = new JTextField();
        destinationField.setBounds(140, 60, 150, 25);
        panel.add(destinationField);

        JLabel lblDate = new JLabel("Travel Date:");
        lblDate.setBounds(30, 100, 100, 25);
        panel.add(lblDate);

        JSpinner dateSpinner = new JSpinner(new SpinnerDateModel());
        dateSpinner.setBounds(140, 100, 150, 25);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "yyyy-MM-dd");
        dateSpinner.setEditor(dateEditor);
        panel.add(dateSpinner);

        JLabel lblBus = new JLabel("Available Buses:");
        lblBus.setBounds(30, 140, 100, 25);
        panel.add(lblBus);

        JComboBox<String> busComboBox = new JComboBox<>();
        busComboBox.setBounds(140, 140, 300, 25);
        panel.add(busComboBox);

        JButton btnSearch = new JButton("Search");
        btnSearch.setBounds(320, 60, 100, 25);
        btnSearch.addActionListener(e -> {
            String source = sourceField.getText().trim();
            String destination = destinationField.getText().trim();
            String selectedDate = new SimpleDateFormat("yyyy-MM-dd").format((Date) dateSpinner.getValue());

            if (source.isEmpty() || destination.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Please enter both source and destination.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String buses = findBuses(source, destination, selectedDate);
            if (buses == null || buses.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "No buses available for the selected route and date.", "Info", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            busComboBox.removeAllItems();
            for (String bus : buses.split("\n")) {
                busComboBox.addItem(bus);
            }
        });
        panel.add(btnSearch);

        JButton btnSelectSeats = new JButton("Select Seats");
        btnSelectSeats.setBounds(200, 200, 150, 30);
        btnSelectSeats.addActionListener(e -> {
            String busDetails = (String) busComboBox.getSelectedItem();
            if (busDetails!= null) {
                try {
                    String[] busInfo = busDetails.split(", ");
                    String busId = busInfo[0];
                    double seatCost = fetchSeatCost(busId);

                    JFrame seatFrameContainer = new JFrame("Seat Selection");
                    seatFrameContainer.setSize(600, 600);
                    seatFrameContainer.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    seatFrameContainer.add(new SeatSelectionFrame(busId, mobile, seatCost));
                    seatFrameContainer.setVisible(true);

                    SwingUtilities.getWindowAncestor(panel).dispose();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(panel, "Error navigating to Seat Selection: " + ex.getMessage(),
                            "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            } else {
                JOptionPane.showMessageDialog(panel, "Please select a bus first.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        panel.add(btnSelectSeats);

        return panel;
    }

    private String findBuses(String source, String destination, String travelDate) {
        StringBuilder result = new StringBuilder();
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bus_ticket", "root", "Jac@231005");
             PreparedStatement ps = con.prepareStatement("SELECT * FROM bus WHERE Source =? AND Destination =? AND Date_Available =? AND Seats_Available > 0")) {
            ps.setString(1, source);
            ps.setString(2, destination);
            ps.setString(3, travelDate);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                result.append(rs.getInt("Bus_Id")).append(", ");
                result.append(rs.getString("Source")).append(", ");
                result.append(rs.getString("Destination")).append(", ");
                result.append(rs.getString("Time_Available")).append(", ");
                result.append(rs.getDate("Date_Available")).append("\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching buses: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return result.toString().trim();
    }

    private double fetchSeatCost(String busId) {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bus_ticket", "root", "Jac@231005");
             PreparedStatement ps = con.prepareStatement("SELECT Price FROM bus WHERE Bus_Id =?")) {
            ps.setString(1, busId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getDouble("Price");
            } else {
                throw new SQLException("Price not found for Bus ID: " + busId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching seat cost: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return 0.0;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            UserHome1 userHome = new UserHome1("", "423356");
            userHome.setVisible(true);
        });
    }
}