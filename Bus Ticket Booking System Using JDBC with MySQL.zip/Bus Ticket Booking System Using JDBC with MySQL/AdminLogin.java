import javax.swing.*;
import java.sql.*;
import java.awt.Font;
import java.awt.Color;

public class AdminLogin extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPasswordField passwordField;

    AdminLogin() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 613, 532);
        setTitle("Admin Login Page");

        getContentPane().setLayout(null);

        JLabel head = new JLabel("Admin Login", JLabel.CENTER);
        head.setFont(new Font("Times New Roman", Font.BOLD, 26));
        head.setForeground(Color.RED);
        head.setBounds(216, 10, 150, 30);
        getContentPane().add(head);
        getContentPane().setBackground(new Color(255, 255, 255));

        JPanel panel = new JPanel();
        panel.setBackground(new Color(32, 178, 170));
        panel.setBounds(10, 59, 579, 426);
        getContentPane().add(panel);
        panel.setLayout(null);

        JLabel lblEmail = new JLabel("Email");
        lblEmail.setBounds(83, 52, 135, 30);
        panel.add(lblEmail);
        lblEmail.setHorizontalAlignment(SwingConstants.CENTER);
        lblEmail.setFont(new Font("Times New Roman", Font.PLAIN, 15));

        JTextField txtEmail = new JTextField(20);
        txtEmail.setBounds(263, 53, 200, 30);
        panel.add(txtEmail);
        txtEmail.setFont(new Font("Times New Roman", Font.PLAIN, 15));

        JLabel lblPass = new JLabel("Password");
        lblPass.setHorizontalAlignment(SwingConstants.CENTER);
        lblPass.setFont(new Font("Times New Roman", Font.PLAIN, 15));
        lblPass.setBounds(89, 128, 129, 30);
        panel.add(lblPass);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Times New Roman", Font.PLAIN, 15));
        passwordField.setBounds(263, 128, 200, 30);
        panel.add(passwordField);

        JButton btnLogin = new JButton("Login");
        btnLogin.setBounds(222, 200, 100, 30);
        panel.add(btnLogin);
        btnLogin.setFont(new Font("Times New Roman", Font.PLAIN, 16));

        btnLogin.addActionListener(e -> {
            String email = txtEmail.getText().trim();
            String password = new String(passwordField.getPassword()).trim();

            if (email.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter your Email.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter the Password.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bus_ticket", "root", "Jac@231005");

                // Query to validate admin credentials
                String sql = "SELECT * FROM admin WHERE Email = ? AND Password = ?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, email);
                ps.setString(2, password);

                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    AdminHome adminHome = new AdminHome(rs.getString("Email"), rs.getString("Name"), rs.getString("Password"));
                    adminHome.setVisible(true);
                    setVisible(false);
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid Login. Please check your credentials.", "Error", JOptionPane.ERROR_MESSAGE);
                }
                con.close();
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    public static void main(String[] args) {
        AdminLogin adminLogin = new AdminLogin();
        adminLogin.setVisible(true);
    }
}