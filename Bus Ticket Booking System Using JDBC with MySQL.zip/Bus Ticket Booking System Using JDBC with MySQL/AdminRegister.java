

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.JTextArea;
import javax.swing.JRadioButton;
import java.awt.Toolkit;
import javax.swing.JButton;
import javax.swing.ButtonGroup;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.JPasswordField;


public class AdminRegister {

	private JFrame frmSignUp;
	private JTextField txtname;
	private JTextField txtmob;
	private JTextField txtemail;
	private JTextField txtage;
	private JRadioButton rbmale;
	private JRadioButton rbfemale;
	private JTextArea txtadd;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JPasswordField passwordField;


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminRegister window = new AdminRegister();
					window.frmSignUp.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public AdminRegister() {
		frmSignUp = new JFrame();
		frmSignUp.setTitle("Sign Up");
		frmSignUp.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\selva\\Downloads\\Related Wallpapers - Register Icon Png White Png Image With Transparent Background.jpg"));
		frmSignUp.getContentPane().setBackground(new Color(100, 149, 237));
		frmSignUp.setBounds(100, 100, 662, 567);
		frmSignUp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSignUp.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Sign Up");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 0, 586, 35);
		frmSignUp.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		panel.setBounds(10, 35, 628, 485);
		frmSignUp.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel name = new JLabel("Name");
		name.setFont(new Font("Times New Roman", Font.BOLD, 13));
		name.setBounds(107, 17, 74, 24);
		panel.add(name);
		
		JLabel mob = new JLabel("Mobile No.");
		mob.setFont(new Font("Times New Roman", Font.BOLD, 13));
		mob.setBounds(107, 67, 74, 24);
		panel.add(mob);
		
		JLabel email = new JLabel("Email");
		email.setFont(new Font("Times New Roman", Font.BOLD, 13));
		email.setBounds(107, 129, 74, 24);
		panel.add(email);
		
		JLabel gender = new JLabel("Gender");
		gender.setFont(new Font("Times New Roman", Font.BOLD, 13));
		gender.setBounds(107, 185, 74, 24);
		panel.add(gender);
		
		JLabel age = new JLabel("Age");
		age.setFont(new Font("Times New Roman", Font.BOLD, 13));
		age.setBounds(107, 239, 74, 24);
		panel.add(age);
		
		JLabel address = new JLabel("Address");
		address.setFont(new Font("Times New Roman", Font.BOLD, 13));
		address.setBounds(107, 300, 74, 24);
		panel.add(address);
		
		txtname = new JTextField();
		txtname.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		txtname.setBounds(262, 20, 170, 21);
		panel.add(txtname);
		txtname.setColumns(10);
		
		txtmob = new JTextField();
		txtmob.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		txtmob.setColumns(10);
		txtmob.setBounds(262, 70, 170, 21);
		panel.add(txtmob);
		
		txtemail = new JTextField();
		txtemail.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		txtemail.setColumns(10);
		txtemail.setBounds(262, 132, 170, 24);
		panel.add(txtemail);
		
		txtage = new JTextField();
		txtage.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		txtage.setColumns(10);
		txtage.setBounds(262, 239, 170, 24);
		panel.add(txtage);
		
		JTextArea txtadd = new JTextArea();
		txtadd.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		txtadd.setBounds(262, 288, 239, 75);
		panel.add(txtadd);
		
		JRadioButton rbmale = new JRadioButton("Male");
		buttonGroup.add(rbmale);
		rbmale.setBackground(new Color(255, 255, 255));
		rbmale.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		rbmale.setBounds(262, 187, 68, 21);
		panel.add(rbmale);
		
		JRadioButton rbfemale = new JRadioButton("Female");
		buttonGroup.add(rbfemale);
		rbfemale.setBackground(new Color(255, 255, 255));
		rbfemale.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		rbfemale.setBounds(348, 187, 74, 21);
		panel.add(rbfemale);
		
		JLabel password = new JLabel("Password");
		password.setFont(new Font("Times New Roman", Font.BOLD, 13));
		password.setBounds(107, 371, 74, 36);
		panel.add(password);
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		passwordField.setBounds(262, 373, 170, 19);
		panel.add(passwordField);
		
		JButton btnNewButton = new JButton("Submit");
		String psw = passwordField.getPassword().toString();
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bus_ticket", "root", "Jac@231005");
                    String query = "insert into admin values(?,?,?,?,?,?,?,?)";
                    PreparedStatement ps = con.prepareStatement(query);
                    ps.setString(1,txtname.getText());
                    ps.setString(2,txtmob.getText());
                    ps.setString(3,txtemail.getText());
                    if(rbmale.isSelected())
                    	ps.setString(4,rbmale.getText());
                    else
                    	ps.setString(4,rbfemale.getText());
                    ps.setInt(5,Integer.parseInt(txtage.getText()));  
                    ps.setString(6, txtadd.getText());
                    ps.setString(7,psw);
                    ps.setDouble(8,0.0);
                    int i = ps.executeUpdate();
                    JOptionPane.showMessageDialog(btnNewButton, i+" Signed up successfully");
                    ps.close();
                    con.close();
				}
				catch (Exception e1) {
					e1.printStackTrace();
				}
				String email = txtemail.getText();
            	String mob = txtmob.getText();
            	String pas = passwordField.getPassword().toString();
            	AdminHome adh = new AdminHome(email, mob, pas);
            	adh.setVisible(true) ;
            	setVisible(false);
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnNewButton.setBounds(186, 454, 85, 21);
		panel.add(btnNewButton);
		
		
		JButton clearbt = new JButton("Clear");
		clearbt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearFields();
        		buttonGroup.clearSelection();
			}
		});
		clearbt.setFont(new Font("Times New Roman", Font.BOLD, 13));
		clearbt.setBounds(297, 454, 85, 21);
		panel.add(clearbt);
		
		JButton btnNewButton_1 = new JButton("Sign In");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserLogin ul = new UserLogin();
				ul.setVisible(true);
				setVisible(false);
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 13));
		btnNewButton_1.setBounds(459, 454, 85, 21);
		panel.add(btnNewButton_1);
		
	
		frmSignUp.setVisible(true);
	}

	public void clearFields() {
        txtname.setText("");
        txtmob.setText("");
        txtemail.setText("");
        rbmale.setSelected(false);
        rbfemale.setSelected(false);
        passwordField.setText("");
        txtage.setText("");
        txtadd.setText("");
        passwordField.setText("");
        //txtAddress.setText("");
    }
	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}
}
