import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class SeatSelectionFrame extends JPanel {
    private static final int ROWS = 5; // Number of rows in the bus
    private static final int COLS = 4; // Number of columns in the bus
    private boolean[][] seats = new boolean[ROWS][COLS]; // Seat availability (true if booked)
    private String busId;
    private String userMobile;
    private double seatCost; // Cost per seat fetched or passed directly
    private JLabel totalCostLabel; // Reference to the total cost label

    public SeatSelectionFrame(String busId, String userMobile, double seatCost) {
        this.busId = busId;
        this.userMobile = userMobile;
        this.seatCost = seatCost;

        setLayout(new BorderLayout());

        JPanel seatPanel = new JPanel(new GridLayout(ROWS, COLS, 10, 10));
        fetchBookedSeats();

        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                JButton seatButton = new JButton();
                seatButton.setBackground(seats[i][j] ? Color.RED : Color.GREEN); // Red for booked, green for available
                seatButton.setOpaque(true);
                seatButton.setBorderPainted(false);

                final int row = i;
                final int col = j;
                seatButton.addActionListener(e -> {
                    if (!seats[row][col]) {
                        seats[row][col] = true; // Select seat
                        seatButton.setBackground(Color.YELLOW); // Yellow for selected
                    } else {
                        seats[row][col] = false; // Deselect seat
                        seatButton.setBackground(Color.GREEN); // Reset to available
                    }
                    updateTotalCostLabel();
                });

                seatPanel.add(seatButton);
            }
        }

        add(seatPanel, BorderLayout.CENTER);

        JPanel controlPanel = new JPanel(new FlowLayout());
        totalCostLabel = new JLabel("Total Cost: ₹0.00");
        controlPanel.add(totalCostLabel);

        JButton btnBookSeats = new JButton("Book Seats");
        btnBookSeats.addActionListener(e -> {
            double totalCost = calculateTotalCost();
            if (totalCost == 0) {
                JOptionPane.showMessageDialog(this, "No seats selected. Please select at least one seat.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean success = saveSelectedSeats(totalCost);
            if (success) {
                JOptionPane.showMessageDialog(this, "Seats booked successfully! Total Cost: ₹" + totalCost);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to book seats. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        controlPanel.add(btnBookSeats);

        add(controlPanel, BorderLayout.SOUTH);
    }

    private void fetchBookedSeats() {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bus_ticket", "root", "Jac@231005")) {
            String sql = "SELECT SeatNo FROM seat_bookings WHERE Bus_Id = ?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, busId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        int seatNo = rs.getInt("SeatNo");
                        int row = seatNo / COLS;
                        int col = seatNo % COLS;
                        seats[row][col] = true; // Mark seat as booked
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error while fetching booked seats: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateTotalCostLabel() {
        double totalCost = calculateTotalCost();
        totalCostLabel.setText("Total Cost: ₹" + totalCost);
    }

    private double calculateTotalCost() {
        int selectedSeats = 0;
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                if (seats[i][j]) {
                    selectedSeats++;
                }
            }
        }
        return selectedSeats * seatCost;
    }

    private boolean saveSelectedSeats(double totalCost) {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bus_ticket", "root", "Jac@231005")) {
            con.setAutoCommit(false); // Start transaction

            // Check if the user exists in the user table
            if (!userExists(con, userMobile)) {
                JOptionPane.showMessageDialog(this, "User not found. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                con.rollback();
                return false;
            }

            // Save seat selection to the database
            for (int i = 0; i < ROWS; i++) {
                for (int j = 0; j < COLS; j++) {
                    if (seats[i][j]) {
                        int seatNo = i * COLS + j;
                        try (PreparedStatement psBooking = con.prepareStatement(
                                "INSERT INTO seat_bookings (Mobile, Bus_Id, SeatNo, Booking_Date) VALUES (?, ?, ?, NOW())")) {
                            psBooking.setString(1, userMobile);
                            psBooking.setString(2, busId);
                            psBooking.setInt(3, seatNo);
                            psBooking.executeUpdate();
                        }
                    }
                }
            }

            con.commit(); // Commit transaction
            return true;
        } catch (SQLException e) {
            if (e.getSQLState().equals("23000")) { // Integrity constraint violation
                JOptionPane.showMessageDialog(this, "Some seats are already booked. Please select different seats.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
            e.printStackTrace();
        }
        return false;
    }

    private boolean userExists(Connection con, String userMobile) throws SQLException {
        String sql = "SELECT COUNT(*) AS count FROM user WHERE TRIM(Mobile) = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, userMobile.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("count") > 0;
                }
            }
        }
        return false;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Seat Selection");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(600, 600);
            frame.setVisible(true);
        });
    }
}