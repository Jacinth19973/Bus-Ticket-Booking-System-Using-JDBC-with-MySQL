import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class UserRegister extends JFrame {
    private static final long serialVersionUID = 1L;
    private JTextField txtName, txtMob, txtEmail, txtAge;
    private JTextArea txtAdd;
    private JRadioButton rbMale, rbFemale;
    private final ButtonGroup buttonGroup = new ButtonGroup();

    public UserRegister() {
        // Set JFrame properties
        setTitle("User Registration");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 600);
        setLocationRelativeTo(null);
        getContentPane().setLayout(null);

        JLabel lblTitle = new JLabel("User Registration", JLabel.CENTER);
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 24));
        lblTitle.setBounds(0, 0, 600, 40);
        getContentPane().add(lblTitle);

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setBounds(50, 50, 500, 450);
        panel.setLayout(null);
        getContentPane().add(panel);

        JLabel lblName = new JLabel("Name:");
        lblName.setFont(new Font("Times New Roman", Font.BOLD, 14));
        lblName.setBounds(30, 30, 100, 25);
        panel.add(lblName);

        txtName = new JTextField();
        txtName.setBounds(150, 30, 250, 25);
        panel.add(txtName);

        JLabel lblMob = new JLabel("Mobile:");
        lblMob.setFont(new Font("Times New Roman", Font.BOLD, 14));
        lblMob.setBounds(30, 80, 100, 25);
        panel.add(lblMob);

        txtMob = new JTextField();
        txtMob.setBounds(150, 80, 250, 25);
        panel.add(txtMob);

        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setFont(new Font("Times New Roman", Font.BOLD, 14));
        lblEmail.setBounds(30, 130, 100, 25);
        panel.add(lblEmail);

        txtEmail = new JTextField();
        txtEmail.setBounds(150, 130, 250, 25);
        panel.add(txtEmail);

        JLabel lblGender = new JLabel("Gender:");
        lblGender.setFont(new Font("Times New Roman", Font.BOLD, 14));
        lblGender.setBounds(30, 180, 100, 25);
        panel.add(lblGender);

        rbMale = new JRadioButton("Male");
        rbMale.setBounds(150, 180, 80, 25);
        rbMale.setBackground(Color.WHITE);
        buttonGroup.add(rbMale);
        panel.add(rbMale);

        rbFemale = new JRadioButton("Female");
        rbFemale.setBounds(250, 180, 80, 25);
        rbFemale.setBackground(Color.WHITE);
        buttonGroup.add(rbFemale);
        panel.add(rbFemale);

        JLabel lblAge = new JLabel("Age:");
        lblAge.setFont(new Font("Times New Roman", Font.BOLD, 14));
        lblAge.setBounds(30, 230, 100, 25);
        panel.add(lblAge);

        txtAge = new JTextField();
        txtAge.setBounds(150, 230, 250, 25);
        panel.add(txtAge);

        JLabel lblAdd = new JLabel("Address:");
        lblAdd.setFont(new Font("Times New Roman", Font.BOLD, 14));
        lblAdd.setBounds(30, 280, 100, 25);
        panel.add(lblAdd);

        txtAdd = new JTextArea();
        txtAdd.setBounds(150, 280, 250, 75);
        txtAdd.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        panel.add(txtAdd);

        JButton btnRegister = new JButton("Register");
        btnRegister.setBounds(150, 380, 100, 30);
        btnRegister.addActionListener(e -> registerUser());
        panel.add(btnRegister);

        JButton btnClear = new JButton("Clear");
        btnClear.setBounds(300, 380, 100, 30);
        btnClear.addActionListener(e -> clearFields());
        panel.add(btnClear);

        setVisible(true);
    }

    private void registerUser() {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bus_ticket", "root", "Jac@231005")) {
            String gender = rbMale.isSelected() ? "Male" : rbFemale.isSelected() ? "Female" : "";
            String query = "INSERT INTO user (name, mobile, email, gender, age, address, wallet) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, txtName.getText());
            ps.setString(2, txtMob.getText());
            ps.setString(3, txtEmail.getText());
            ps.setString(4, gender);
            ps.setInt(5, Integer.parseInt(txtAge.getText()));
            ps.setString(6, txtAdd.getText());
            ps.setDouble(7, 0.0);

            int rows = ps.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "User registered successfully!");
                dispose();
                new UserLogin().setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to register user.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void clearFields() {
        txtName.setText("");
        txtMob.setText("");
        txtEmail.setText("");
        txtAge.setText("");
        txtAdd.setText("");
        buttonGroup.clearSelection();
    }

    public static void main(String[] args) {
        new UserRegister();
    }
}