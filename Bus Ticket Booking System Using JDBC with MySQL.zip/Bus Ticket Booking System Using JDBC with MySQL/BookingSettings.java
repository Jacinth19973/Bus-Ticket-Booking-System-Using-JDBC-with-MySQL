import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class BookingSettings extends JFrame {
    private static final long serialVersionUID = 1L;

    public BookingSettings(String mobile) {
        // Set JFrame properties
        setTitle("Book Tickets");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        // Create panel for booking functionality
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(240, 230, 140));

        JLabel lblSource = new JLabel("Source:");
        lblSource.setBounds(30, 20, 100, 25);
        panel.add(lblSource);

        JTextField sourceField = new JTextField();
        sourceField.setBounds(140, 20, 150, 25);
        panel.add(sourceField);

        JLabel lblDestination = new JLabel("Destination:");
        lblDestination.setBounds(30, 60, 100, 25);
        panel.add(lblDestination);

        JTextField destinationField = new JTextField();
        destinationField.setBounds(140, 60, 150, 25);
        panel.add(destinationField);

        JLabel lblBus = new JLabel("Available Buses:");
        lblBus.setBounds(30, 100, 100, 25);
        panel.add(lblBus);

        JComboBox<String> busComboBox = new JComboBox<>();
        busComboBox.setBounds(140, 100, 300, 25);
        panel.add(busComboBox);

        JButton btnSearch = new JButton("Search");
        btnSearch.setBounds(320, 40, 100, 25);
        btnSearch.addActionListener(e -> {
            String source = sourceField.getText().trim();
            String destination = destinationField.getText().trim();

            if (source.isEmpty() || destination.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Please enter both source and destination.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String buses = findBuses(source, destination);
            if (buses == null || buses.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "No buses available for the selected route.", "Info", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            busComboBox.removeAllItems();
            for (String bus : buses.split("\n")) {
                busComboBox.addItem(bus);
            }
        });
        panel.add(btnSearch);

        JButton btnBookTickets = new JButton("Book Tickets");
        btnBookTickets.setBounds(200, 140, 150, 30);
        btnBookTickets.setEnabled(false); // Initially disabled
        btnBookTickets.addActionListener(e -> {
            String selectedBus = (String) busComboBox.getSelectedItem();
            if (selectedBus != null) {
                try {
                    String[] busDetails = selectedBus.split(", ");
                    String busId = busDetails[0]; // Assuming Bus ID is the first value
                    double seatCost = fetchSeatCost(busId); // Fetch seat cost from database

                    JFrame seatFrame = new JFrame("Seat Selection");
                    seatFrame.setSize(600, 600);
                    seatFrame.add(new SeatSelectionFrame(busId, mobile, seatCost));
                    seatFrame.setVisible(true);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(panel, "Error processing seat selection: " + ex.getMessage(),
                            "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            } else {
                JOptionPane.showMessageDialog(panel, "Please select a bus first.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        panel.add(btnBookTickets);

        // Enable the "Book Tickets" button when a bus is selected
        busComboBox.addActionListener(e -> {
            btnBookTickets.setEnabled(busComboBox.getSelectedItem() != null);
        });

        add(panel);
    }

    private String findBuses(String source, String destination) {
        StringBuilder result = new StringBuilder();
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bus_ticket", "root", "Jac@231005");
             PreparedStatement ps = con.prepareStatement("SELECT * FROM bus WHERE Source = ? AND Destination = ? AND Seats_Available > 0")) {
            ps.setString(1, source);
            ps.setString(2, destination);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                result.append(rs.getInt("Bus_Id")).append(", ");
                result.append(rs.getString("Source")).append(", ");
                result.append(rs.getString("Destination")).append(", ");
                result.append(rs.getString("Time_Available")).append(", ");
                result.append(rs.getDate("Date_Available")).append("\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching buses: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return result.toString().trim();
    }

    private double fetchSeatCost(String busId) {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bus_ticket", "root", "Jac@231005");
             PreparedStatement ps = con.prepareStatement("SELECT Price FROM bus WHERE Bus_Id = ?")) {
            ps.setString(1, busId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getDouble("Price");
            } else {
                throw new SQLException("Price not found for Bus ID: " + busId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching seat cost: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return 0.0;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            BookingSettings bookingSettings = new BookingSettings("1234567890");
            bookingSettings.setVisible(true);
        });
    }
}